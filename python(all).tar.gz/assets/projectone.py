# print("Welcome to Yora AI")

# while True:

#     user_input = input("You: ")

#     if user_input.lower() == "bye":
#         print("Yora AI: Goodbye!")
#         break

#     elif "hello" in user_input.lower():
#         print("Yora AI: Hello Yachu! How are you?")

#     elif "name" in user_input.lower():
#         print("Yora AI: My name is Yora AI.")

#     else:
#         print("Yora AI: I am still learning.")


# import sqlite3
# from datetime import datetime

# # Database Connection
# conn = sqlite3.connect("memory.db")
# cursor = conn.cursor()

# # Create Table
# cursor.execute("""
# CREATE TABLE IF NOT EXISTS chats (
#     id INTEGER PRIMARY KEY AUTOINCREMENT,
#     user_message TEXT,
#     bot_reply TEXT
# )
# """)

# print("=" * 50)
# print("           WELCOME TO YORA AI")
# print("=" * 50)
# print("Commands:")
# print("hello")
# print("my name is <your name>")
# print("time")
# print("date")
# print("history")
# print("bye")
# print("=" * 50)

# user_name = ""

# while True:

#     user_input = input("\nYou: ").strip()

#     # Exit
#     if user_input.lower() == "bye":
#         reply = "Goodbye! Have a great day."
#         print("Yora AI:", reply)

#         cursor.execute(
#             "INSERT INTO chats (user_message, bot_reply) VALUES (?, ?)",
#             (user_input, reply)
#         )
#         conn.commit()
#         break

#     # Save Name
#     elif user_input.lower().startswith("my name is"):

#         user_name = user_input[10:].strip()

#         if user_name == "":
#             reply = "Please tell me your name properly."
#         else:
#             reply = f"Nice to meet you, {user_name.title()}!"

#     # Hello
#     elif "hello" in user_input.lower():

#         if user_name:
#             reply = f"Hello {user_name.title()}! How are you?"
#         else:
#             reply = "Hello! Please tell me your name."

#     # Time
#     elif "time" in user_input.lower():
#         reply = datetime.now().strftime("Current Time: %H:%M:%S")

#     # Date
#     elif "date" in user_input.lower():
#         reply = datetime.now().strftime("Today's Date: %d-%m-%Y")

#     # AI Name
#     elif "your name" in user_input.lower():
#         reply = "My name is Yora AI."

#     # History
#     elif "history" in user_input.lower():

#         cursor.execute("SELECT * FROM chats")
#         records = cursor.fetchall()

#         print("\n========== CHAT HISTORY ==========")

#         if len(records) == 0:
#             print("No chats found.")
#         else:
#             for row in records:
#                 print(f"ID: {row[0]}")
#                 print(f"You : {row[1]}")
#                 print(f"Yora: {row[2]}")
#                 print("-" * 30)

#         continue

#     else:
#         reply = (
#             "I am still learning. "
#             "Try commands like hello, date, time, history or my name is."
#         )

#     print("Yora AI:", reply)

#     # Save Chat
#     cursor.execute(
#         "INSERT INTO chats (user_message, bot_reply) VALUES (?, ?)",
#         (user_input, reply)
#     )

#     conn.commit()

# conn.close()

#api key:  AQ.Ab8RN6KlZNX76DcoOL1R2ltpKV_IW9gHpR0NPANienKmF3KUlg

# import google.generativeai as genai

# # API Key
# genai.configure(api_key="AQ.Ab8RN6KlZNX76DcoOL1R2ltpKV_IW9gHpR0NPANienKmF3KUlg")

# # Gemini Model
# model = genai.GenerativeModel("gemini-2.0-flash")

# print("=" * 50)
# print("         YORA AI - REAL AI MODE")
# print("=" * 50)
# print("Type 'bye' to exit")
# print()

# while True:

#     user_input = input("You: ")

#     if user_input.lower() == "bye":
#         print("Yora AI: Goodbye!")
#         break

#     try:

#         response = model.generate_content(user_input)

#         print("\nYora AI:")
#         print(response.text)
#         print()

#     except Exception as e:
#         print("Error:", e)

# import google.generativeai as genai

# genai.configure(api_key="AQ.Ab8RN6KlZNX76DcoOL1R2ltpKV_IW9gHpR0NPANienKmF3KUlg")

# for model in genai.list_models():
#     print(model.name)


# import google.generativeai as genai

# genai.configure(api_key="AQ.Ab8RN6KlZNX76DcoOL1R2ltpKV_IW9gHpR0NPANienKmF3KUlg")

# model = genai.GenerativeModel("models/gemini-2.5-flash")

# response = model.generate_content("Who are you?")

# print(response.text)


####FINAL CODE

import google.generativeai as genai
import sqlite3
from datetime import datetime

# ==========================
# GEMINI API CONFIG
# ==========================

genai.configure(api_key="AQ.Ab8RN6KlZNX76DcoOL1R2ltpKV_IW9gHpR0NPANienKmF3KUlg")

model = genai.GenerativeModel("models/gemini-2.5-flash")

# ==========================
# DATABASE
# ==========================

conn = sqlite3.connect("memory.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS chats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_message TEXT,
    bot_reply TEXT
)
""")

conn.commit()

# ==========================
# WELCOME
# ==========================

print("=" * 50)
print("           YORA AI")
print("=" * 50)
print("Commands:")
print("my name is <name>")
print("date")
print("time")
print("history")
print("bye")
print("=" * 50)

user_name = ""

# ==========================
# MAIN LOOP
# ==========================

while True:

    user_input = input("\nYou: ")

    # Exit
    if user_input.lower() == "bye":

        print("Yora AI: Goodbye!")

        cursor.execute(
            "INSERT INTO chats(user_message, bot_reply) VALUES (?, ?)",
            (user_input, "Goodbye!")
        )

        conn.commit()
        break

    # Save Name
    elif user_input.lower().startswith("my name is"):

        user_name = user_input[10:].strip()

        reply = f"Nice to meet you, {user_name.title()}!"

        print("Yora AI:", reply)

    # Date
    elif user_input.lower() == "date":

        reply = datetime.now().strftime(
            "Today's Date: %d-%m-%Y"
        )

        print("Yora AI:", reply)

    # Time
    elif user_input.lower() == "time":

        reply = datetime.now().strftime(
            "Current Time: %H:%M:%S"
        )

        print("Yora AI:", reply)

    # History
    elif user_input.lower() == "history":

        cursor.execute("SELECT * FROM chats")

        records = cursor.fetchall()

        print("\n========== CHAT HISTORY ==========")

        if len(records) == 0:
            print("No chat history found.")

        else:

            for row in records:

                print("\nID:", row[0])
                print("You :", row[1])
                print("Yora:", row[2])

        continue

    # Gemini AI
    else:

        try:

            prompt = user_input

            if user_name:
                prompt = (
                    f"The user's name is {user_name}. "
                    f"Answer this question:\n{user_input}"
                )

            response = model.generate_content(prompt)

            reply = response.text

            print("\nYora AI:")
            print(reply)

        except Exception as e:

            reply = f"Error: {str(e)}"

            print(reply)

    # Save Chat
    cursor.execute(
        "INSERT INTO chats(user_message, bot_reply) VALUES (?, ?)",
        (user_input, reply)
    )

    conn.commit()

conn.close()



















