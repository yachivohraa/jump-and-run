
import numpy as np
'''
arr=np.array([10,20,30,40,50])   #1D array
print(arr)
print(type(arr))
a=[10,20] 
print(a)
print(type(a))
b=np.array(98)     #0D array
print(b)
print(type(b))
d=np.array([[10,20,30,40],[50,60,70,80]])      #2D array
print(d)
print(type(d))
E=np.array([[[10,20,30],[40,50,60],[70,80,90]]])           #3D array
print(E)
print(E.ndim)  #ndim use to find dimension
f=np.array([[[[10,20],[30,40],[50,60],[70,80]]]])          #4D array
print(f.ndim)
#--------------------------------

c=np.array([10,20,30,40,50])        #double
print(c*2)

arr3=np.array([[10,20,30,40],[90,80,60,80]])            
print((arr3[0][1])+(arr3[0][0]))                    #sum of indexing ka index

#---------------
import numpy as np

arr=np.array([10,20,30,40])             
for i in arr:                                                  #loop in numpy
    print(i)

d=np.array([[10,20,30,40],[50,60,70,80]])
for i in d:
    for h in i:                                                 #nested loop
        print(h)

E=np.array([[[10,20,30],[40,50,60],[70,80,90]]])
for i in E:
    for h in i :
        for j in h:
            print(j)

#----

a=np.array([10,20,30,40,-67,88,0,-99,0])
for i in a:
    if (i>0):
        print(i,'= +ve')                                     #loop + conditional statement
    elif(i<0):
        print(i,'=-ve')
    elif (i==0):
        print(i,'zero')


#---
a=np.array([67,88,63,44,78,99,0])
sum=0
for i in a:                              #total of the array 
    sum=sum+i
print(sum)


#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
import numpy as np

a= np.array([10,20,30,40,50])
#print(a)
x=a.copy()               #copy
a[0]=55
print(a)
print(x)     #if you create a copy of array it doesnt mean the copy will be updated


#----view

import numpy as nd
a= nd.array([10,20,30,40,50])
x= a.view()
a[0]=77
print(a)           #if you change the element of any of array or copy or variable it will change both
print(x)


#-------------shape
import numpy as np

  #if u want to change the shape then u have to check the length of an element

a= np.array([[1,2,3,4,5,6,7],[23,45,12,11,30,76,55]])
print(a.shape)


#-----------reshape
import numpy as np
#1d to 2d

a= np.array([1,2,3,4,5,6,7,8,9,10,11,12])
print(len(a)) #length
b=a.reshape(2,6)        #first digit - column , second digit- row,    if there is 2 values in bracket then its 2d
print(b)

c= np.array([10,89,33,56,12,10,34,65,76])
d=c.reshape(3,3)
print(d)

e=c= np.array([10,89,33,56,12,10,34,65,76,88,23,55,90,44,55])
f=e.reshape(5,3)
print(f)

#2d to 1d

a=np.array([[1,2,3,4],[5,6,7,8]])
b=a.flatten()
print(b)


#1d to 3d

a=np.array([89,33,56,12,10,34,65,76,88,23,55,90])
b= a.reshape(3,2,2)
print(b)
           
#3d to 1d
a=np.array([[[10,20,30],[40,50,60],[70,80,90]]])
b=a.flatten()
print(b)

a=np.array([10,89,33,56,12,10,34,65,76,88,23,55,90,44,55])
b=a.reshape(3,1,5)
print(b)

#1d to 4d
a=np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20])
b=a.reshape(4,1,5,1)
print(b)
'''
'''
#iterating - process which can differentiate any dimensions and print the value in single line.

a=np.array([10,20,30,40,50,60,70,80,90])
b=0
for i in a:
    b=b+i
print(b)


a=np.array([[10,20,30,40],[60,70,80,90]])
b=a.flatten()
print(b)
sum=0
for i in b:
    sum=sum+i
print(sum)


#joints
import numpy as np

arr1 = np.array([1,2,3])
arr2 = np.array([4,5,6])
arr= np.concatenate((arr1,arr2))       #concatenate: it converts two array into 1d array
print(arr)


arr1 = np.array([[1,2,3],[9,8,7]])
arr2 = np.array([[4,5,6],[0,1,2]])
arr= np.concatenate((arr1,arr2),axis=1)       #will use axis to concatenate
print(arr)

arr1 = np.array([[1,2,3],[9,8,7]])
arr2 = np.array([[4,5,6],[0,1,2]])
arr= np.concatenate((arr1,arr2))            #won't concatenate, will do normal printing 
print(arr)

arr1 = np.array([[[1,2,3],[9,8,7],[8,8,7]]])
arr2 = np.array([[[4,5,6],[0,1,2],[5,5,4]]])
arr = np.concatenate((arr1,arr2),axis=2)
print(arr)


arr1 = np.array([1,2,3])
arr2 = np.array([4,5,6])
arr= np.hstack((arr1,arr2))
print(arr)

arr1 = np.array([[[1,2,3],[9,8,7],[8,8,7]]])
arr2 = np.array([[[4,5,6],[0,1,2],[5,5,4]]])
arr = np.hstack((arr1,arr2))
print(arr)

arr1 = np.array([[[1,2,3],[9,8,7],[8,8,7]]])
arr2 = np.array([[[4,5,6],[0,1,2],[5,5,4]]])
arr = np.vstack((arr1,arr2))
print(arr)

 #question

a= np.array([[1,2,3],[4,5,6]])
b=  np.array([[1,2,3],[4,5,6]])
c=  np.array([[1,2,3],[4,5,6]])
d= np.concatenate((a,b,c), axis=1)
print(d)

a = np.array([[[1,2,3],[4,5,6],[7,8,9]]])
b=  np.array([[[1,2,3],[4,5,6],[7,8,9]]])
c = np.array([[[1,2,3],[4,5,6],[7,8,9]]])
d = np.array([[[1,2,3],[4,5,6],[7,8,9]]])
e = np.concatenate((a,b,c,d), axis =2)
print(e)


#split
#splitting is the reverse of joining (refers to one array converting into many but in the form of elements)
import numpy as np

a=np.array([1,2,3,4,5,6])
b= np.array_split(a,3)
print(b)


a=np.array([1,2,3,4,5,6])
b= np.array_split(a,4)
print(b)


print(b[0])
print(b[1])
print(b[2])

c=np.array([[1,2],[3,4],[5,6],[7,8],[9,10],[11,12]])
d=np.array_split(c,3)
print(c)

e=np.array([[1,2,3],[4,5,6],[7,8,9],[10,11,12],[13,14,15],[16,17,18]])
f= np.array_split(e,3)
print(f)

e=np.array([[1,2,3],[4,5,6],[7,8,9],[10,11,12],[13,14,15],[16,17,18]])     #spliting of 2d array
f= np.array_split(e,3,axis=1)
print(f)

e=np.array([[[1,2,3],[4,5,6],[7,8,9],[10,11,12],[13,14,15],[16,17,18]]])
f= np.array_split(e,3,axis=2)
print(f)

#duplicacy

a=np.array([1,2,3,3,5,4,1,0])
x=np.where(a==3)
print(x)

a=np.array([1,2,3,3,5,4,1,0,1])
x=np.where(a==1)
print(x)

a=np.array([10,33,22,15,88,90])
x=np.where(a%2==0)          #even
print(x)

a=np.array([10,33,22,15,88,90])
x=np.where(a%2!=0)          #odd
print(x)

a=np.array(["gurnheer","yachi","yash","gurnheer","yash","hrishabh","amit"])
b=np.where(a=="gurnheer")
print(b)

a=np.array(["gurnheer","yachi","yash","gurnheer","yash","hrishabh","amit"])
result=np.char.startswith(a,'y')            #store the name start from y
na=a[result]       #stored in this to print the names 
print(na)

a=np.array(["gurnheer","yachi","yash","gurnheer","yash","hrishabh","amit","hira","prem"])
b=a[np.char.str_len(a)==5]
print(b)

a=np.array([["gurnheer","yachi","yash"],["gurnheer","yash","hrishabh"]])
b=a[np.char.str_len(a)>5]
print(b)

#a=np.array(["gurnheer","yachi","yash","gurnheer","yash","hrishabh","amit","heera"])
#result=np.char,endswith(a,'a')            
#na=a[result]       
#print(na)

#in loop: used to find the range automatically taken by the loop variable.

a=np.array(["gurnheer","yachi","yash","gurnheer","yash","hrishabh","amit"])
for i in a:
    if 'a' not in i:
        print(i)

a=np.array(["gurnheer","yachi","yash","gurnheer","yash","hrishabh","amit"])
b=np.char.capitalize(a)
print(b)


a=np.array(["gurnheer","yachi","yash","gurnheer","yash","hrishabh","amit"])
for i in a:
    print(i[0]+i[1].upper()+i[2])


#practice questions


import numpy as np

#1
a= np.array([10,20,30,40,50])
print(a)
print(a.shape)
print(type(a))
print(a.ndim)

#2
a=np.zeros((3,3), dtype='int')
b=np.ones((3,3), dtype='int')
print(a)
print(b)
'''
'''
#3
for i in range(2,21,2):
    print(i)

#4
i=np.array([1,2,3,4,5,6,7,8,9,10,11,12])
b= i.reshape((3,4))
print(b)

#5
a= np.array([5,10,15,20,25])
print(a[2])
print(a[4])
'''
'''
#6
a=np.array([1,2,3,4,5,6,7,8])
b=a[2:5]
print(b[::2])


#7
a=np.array([1,2,3,4,5])
b=a.astype(float)
print(b)

#8
a=np.array([1,2,3,4,5])
b=a.copy()
c=a.view()
a[0]=35
print(a)
print(b)
print(c)

#9
a=np.array([50,10,40,20,30])
b=np.sort(a)
c=b[b>=25]
print(b)
print(c)

#10
a=np.array([1,2,3])
b=np.array([4,5,6])
c=np.concatenate((a,b))
d=np.array_split(c,3)
print(c)
print(d)

#bonus
a=np.array([10,15,20,25,30])
b=a[a%2==0]
print(b)


#question

a=[1.3,4.5,6.7,7,2]
if all (isinstance(k, float) for k in a):
    arr=np.array(a)
    print(arr)

else:
    raise ValueError("wrong value")


a=input('enter a number')
if all (isinstance(k, float) for k in a):
    arr=np.array(a)
    print(arr)

else:
    raise ValueError("wrong value")

import numpy as np

a=[[[4.8,5.6,7.8],[6.9,8.9,9.9],[7.6,7.8,5.9]]]
if all(isinstance(i, float) for sub1 in a for sub2 in sub1 for i in sub2):
    arr=np.array(a)
    print(arr)

else:
    raise ValueError("wrong value")


a=np.array([[[20,40,60],[87,66,24],[900,20,58]]])
for i in a:
    for k in i:
        for c in k:
            if (c%2==0):
                print('even')
            else:
                print('odd')

 
#practice

#1
a=np.array([10,20,30,40])
print(a.ndim)
print(a.shape)
print(a.dtype)
print(a.size)

#2
a=np.array([[1,2,3],[4,5,6]])
print(a.ndim)
print(a.shape)

#3
a=np.array([5,10,15,20])
print(a)

#4
a=np.array([1,2,3,4,5,6])
b=a.reshape(2,3)
print(b)
c=a.reshape(3,2)
print(c)

#5
a=np.array([[1,2,3],[4,5,6]])
print(a.flatten())

#6
a=np.array([[1,2],[3,4]])
for i in a:
    for b in i:
        print(b)
  

#7
a=np.array([1,2,3])
b=np.array([4,5,6])
c=np.concatenate((a,b))
print(c)

#8
a=np.array([10,20,30,40,50,60])
b=np.array_split(a,3)
print(b)

#9
a=np.array([1,2,2,3,4,4,5])  #[remove duplicacy]
b=np.array(list(set(a)))
print(b)
c=[int(i) for i in a if list(a).count(i)>1]
print(set(c))

#10
a=np.array([1,2,3,4])
b=a.astype('float')
print(b)

#12
a=np.array([[[1,2],[4,5],[6,7]]])
print(a.shape)
print(a.ndim)
print(a.flatten())

#13
#view vs copy : view changes when we change the original, meanwhile copy didn't modify when we make a change in original

#14
#concatenate vs stack : we need to use axis for concatenate, meanwhile there is no need to use axis for stack.

#15
#numpy: numpy refers to the python library used for numerical computation and works with array instead of lists and can also solve large datasets fast.
#ndarray : main object of numpy and stores value in tabular format (rows & columns)
#iterating : process which can differentiate any dimensions and print the value in single line.
#spliting : process which can split the array in the form of elements.

#16
a= np.array([1,2,3,4,5,6,7,8])
b=a.reshape(2,4)
print(b)
c=np.array_split(a,2)
print(c)
print(a.flatten())

#17
a=np.array([10,20,30,40,50])
print(a.ndim)
print(a.shape)
print(a.size)
print(a.dtype)

#18
a=np.array([1,2,3,4,5,6])
b=a.reshape(2,3)
print(b)
c=a.flatten()
print(c)

#19
a=np.array([[1,2,],[3,4]])
#nditer

#20
a=np.array([1,2,3])
b=np.array([4,5,6])
c=np.concatenate((a,b))
print(c)
d=np.hstack((a,b))
print(d)
e=np.vstack((a,b))
print(e)

#21
a=np.array([10,20,30,40,50,60])
b=np.array_split(a,3)
print(b)

#22
a=np.array([1,2,2,3,4,4,5])
#remove how

#23
a=np.array([1,2,3,4])
b=a.astype('float')
print(b)

#24
a=np.array([[1,2],[3,4]])
b=np.array([[5,6],[7,8]])
c=np.dot(a,b)       #use dot to multiply matrix
print(c)

#25
a=np.array([10,20,30,40,50])
b=a[a>25]
print(b)

#26
#a=np.array([[10,20],[30,40]])
#for i in range:

#27
a=np.array([1,2,3])
b=a.view()
b[1]=24
print(a)
print(b)



#test
import numpy as np

#1
a=np.array([[12,14],[18,20],[78,32]])
sum=0
for i in a:
    for b in i:
        sum=sum+b
print(sum)

#2
a=np.array([10,20,30,40,50,60,70,80])
b=a[3:7]
c=sum(b)
print(b)
print(c)

#3
#there is no difference between stack and concatenate

arr1 = np.array([[[1,2,3],[9,8,7],[8,8,7]]])
arr2 = np.array([[[4,5,6],[0,1,2],[5,5,4]]])
arr = np.concatenate((arr1,arr2),axis=2)
print(arr)
ar=np.stack((arr1,arr2),axis=2)
print(ar)

#4
first=np.array([10,20,30,40])
second=np.array([[1,2,3,4],[5,6,7,8]])

c=second.flatten()
print(c)
y=np.concatenate((first,c))
print(y)
d=y.reshape(3,4)
print(d)

#5
a=np.array([[[19,20,31],[90,10,22],[80,40,75]]])
for i in a:
    for b in i:
        for c in b:
            if (c>25):
                d=c+1
                print(d)

'''
import numpy as np
from numpy import random

#SHUFFLE
'''
a=np.array([10,20,30,40,50])
random.shuffle(a)
print(a)

a=np.array([[1,2,3,4,5],[10,20,30,40,50]])
random.shuffle(a)
print(a)
'''

#rangeint
#otpgeneration
import random
'''
num=random.randint(1000,9999)
print(num)

num2=random.randint(100000,999999)
print(num2)

otp=str(random.randint(0,9999)).zfill(4)
print(otp)
'''

import numpy as np
from numpy import random
'''
otp=str(random.randint(0,9999)).zfill(4)
print(otp)

num=random.randint(1000,9999)
print(num)

num2=random.randint(100000,999999)
print(num2)

a=[1,2,3,4,5,6,7,8,9]
otp=''
for i in range(4):
    otp+=str(random.choice(a))
print(otp)



'''
'''
a=[0,1,2,3,4,5,6,7,8,9]                               #how many times
otp=''
count=0
for i in range(4):
    d=random.choice(a)
    otp+=str(d)
    if d==1:
        count+=1
print(otp)
print(count)
'''
#q1
'''
a=np.array([[11,12,21,31],[51,61,71,81]])                               #how many times
otp=''
count=0
b=a.flatten()
for i in range(2):
    d=random.choice(b)
    otp+=str(d)
    if d==1:
        count+=1
print(otp)
print(count)

#direct
a=np.array([[11,12,13],[14,15,16]])
print(str(np.random.choice(a.flatten()))+str(np.random.choice(a.flatten())))
'''
#2
'''
a=np.array([1,2,3,4,5,6,7,8])
otp=''
for i in range(4):
    otp+=str(random.choice(a))
print(otp)
for i in range(1):
    otp+=str(random.choice(a))
print(otp)
for i in range(1):
    otp+=str(random.choice(a))
print(otp)
'''

#SEABORN - shows data in graphical format, it cab be line graph as well as bar graph.
import seaborn as sns
import matplotlib.pyplot as plt
'''
data=[2,3,5,7,5,4,2,1,0,8,7,5,3,4,1]
sns.displot(data)
plt.show()

data=np.array([2,3,5,7,5,4,2,1,0,8,7,5,3,4,1])
sns.displot(data)
plt.show()

a=np.array([1,2,3,4,5,6,7,8])
even=0
odd=0
for i in a:
    if i%2==0:
        even+=1
    else:
        odd+=1
plt.bar(['even','odd'],[even,odd],color=['black','red'])        #done from matplotlib
plt.show()
'''
#revision questions
'''
#1
a=np.array([0,1,2,3,4,5,6,7,8,9])
otp=''
for i in range(4):
    otp+=str(random.choice(a))
print(otp)

#2  (doubt)
a=[1,2,3,4]
b=random.choice(a)
print(b)



#3
a=np.array([1,2,3,4,5,6,7,8,9])
for i in range(5):
    print(random.choice(a))

#4
a=[1,2,3,4,5,6,7,8,9,10]
count=0
for i in range(10):
    d=random.choice(a)
    print(d)
    if d==1:
        count+=1
print(count)


#5
a=np.array([1,2,3,4,5,6])
otp=''
for i in range(6):
    otp+=str(random.choice(a))
print(otp)

#6
a=[1,2,3,4,5,6,7,8,9]
count=0
for i in range(5):
    b=random.choice(a)
    print(b)
    if d==1:
        count+=1
print('count of 1:' , count)

#7
a=np.array([[10,20,30],[40,50,60]])
b=a.flatten()
for i in range(3):
    print(random.choice(b))

'''#8
import numpy as np
import random
'''
a=[1,2,3,4,5,6,7,8]
otp=[]
for i in range(4):
    num=random.choice(a)
    otp.append(num)
print(otp)
even=[]
odd=[]
for num in otp:
    if num%2==0:
        even.append(num)
    else:
        odd.append(num)
print(even)
print(odd)
'''

#2nd method
'''
a=[1,2,3,4,5,6,7,8]
otp=''
for i in range(4):
    otp+=str(random.choice(a))
print(otp)

even=0
odd=0

for character in otp:
    num=int(character)
    if num%2==0:
        even+=1
    else:
        odd+=1
print(even)
print(odd)
'''

import numpy as np
import seaborn as sb
import matplotlib.pyplot as plt
'''
a=np.array([1,2,3,4,5])
even=0
odd=0
for i in a:
    if i%2==0:
        even+=1
    else:
        odd+=1
labels=["EVEN","ODD"]
counts=[even,odd]

sb.barplot(x=labels, y=counts, palette=['black','red'])     #done from seaborn
plt.show() '''

# import numpy as np
# from numpy import random
# otp=str(random.randint(0,9999)).zfill(4)
# print(otp)

'''
otp=""
for i in range(4):
    otp+=str(random.randint(0,9))
print(otp)'''

import numpy as np
import random
'''
a=np.array([1,2,3,4,5,6,7,8,9])
otp=''
for i in range(4):
    otp+=str(random.choice(a))
print(otp)
'''
'''
#challenge question 
import numpy
import string

otp=''.join(np.random.choice(list(string.ascii_letters+string.digits),6))
print(otp)
'''
import numpy as np 
import seaborn as sb 
import matplotlib.pyplot as plt
'''
a= np.array([12,15,30,56,78,93,25.37])
b=0
c=0
for i in a:
    if i>=25:
        b+=1
    else:
        c+=1
plt.bar(['greater than', 'less than'],[b,c],color=["black","green"])
plt.show()


a=['Gurnheer','gagan','riya','raghav','Gaurav']
b=0
c=0
for i in a:
    if i[0].startswith("g"):
        b+=1
    else:
        c+=1
plt.bar(['g name','others'],[b,c],color=('black','red'))
plt.show()
'''
'''
#1  (endswith)
a=['gunheer','mehar','riya','priya','kehar']
b=0
c=0
for i in a:
    if i.endswith('r'):
        b+=1
    else:
        c+=1
plt.bar(['r name','others'],[b,c],color=('black','red'))
plt.show()

arr1=[random.randint(1,10) for i in range(5)]
arr2=[random.randint(1,10) for i in range(5)]
arr3=[arr1[i]+arr2[i] for i in range (len(arr1))]
print('array1',arr1)
print('array2',arr2)
print('sum array', arr3)
'''

#practice
'''
#1
a=[random.randint(1,50) for i in range(10)]
print(a)

#2
a=[random.randint(1,100) for i in range(8)]
print(a)

#3
arr1=[random.randint(1,10) for i in range(5)]
arr2=[random.randint(1,10) for i in range(5)]
arr3=[arr1[i]+arr2[i] for i in range (len(arr1))]
print('array1',arr1)
print('array2',arr2)
print('sum array', arr3)

#4
arr1=[random.randint(1,10) for i in range(10)]
even=0
odd=0
for i in arr1:
    if i%2==0:
        even+=1
    else:
        odd+=1
print("array",arr1)
print("count of even", even)
print("count of odd", odd)
'''
import numpy as np
import seaborn as sb
import matplotlib.pyplot as plt
'''

a=np.array(['a','f','h','i','o','h','p','q','s','r','u','i','i','e'])
vowels='aeiou'
v_vowel=0
c_consonent=0
for i in a:
    if i.lower() in vowels:
        v_vowel+=1
    else:
        c_consonent+=1
data=[]
for v in range(v_vowel):
    data=data + ['VOWEL']
for c in range(c_consonent):
    data=data + ['CONSONANT']

sb.histplot(x=data, kde=True, hue=data ,palette={'VOWEL':'black','CONSONANT':'red'})
plt.show()

a=np.array(['a','c','d','e','k','e','l','o','u','i','i','l','d','v','s'])
vowels='aeiou'
v=0
c=0
for i in a:
    if i.lower() in vowels:
        v+=1
    else:
        c+=1
data=[]
for k in range(v):
    data= data+ ['VOWEL']
for m in range(c):
    data= data+['CONSONANT']
sb.histplot(x=data, kde=True, hue=data, palette={'VOWEL':'red','CONSONANT':'black'})
plt.show()
'''

#if u r using diff colors then store data into variable and then use hue 
#hue is tally the data acc to our given palette but kde will not work.
'''
a=np.array(['a','f','h','i','o','h','p','q','s','r','u','i','i','e'])
vowels='aeiou'
v_vowel=0
c_consonent=0
for i in a:
    if i.lower() in vowels:
        v_vowel+=1
    else:
        c_consonent+=1
data=[]
for v in range(v_vowel):
    data=data + ['VOWEL']
for c in range(c_consonent):
    data=data + ['CONSONANT']

sb.histplot(x=data, kde=True, hue=data ,palette={'VOWEL':'black','CONSONANT':'red'})
plt.show()
'''

#distribution 
#normal distribution : at a single time we can generate ids or random number at a time. there are no fixed ratio to generate the numbers,
#size is declare in normal distribution to used how many number can generate at one time and stored in array. 
#size, scale, loc 

#size (normal distribution)
#normal distributioin random range is -infinity to infinity
import numpy as np
from numpy import random 
'''
grp=random.normal(size=(4,3))
print(grp)

gep=random.randint(1000,9999, size=(4,3))
print(gep)
'''
#when size is alone that means how many digits they are generating
#scale : means how much array they generate
#abs here generate the range into 0-9
'''
grp=random.normal(size=4, scale=3, loc=5)
grp=abs(grp).astype(int)%10
otp=''
for  i in grp:
    otp=otp+str(i)
print(otp)
'''
'''
grp=random.normal(size=(4,3), scale=9999+)
grp=abs(grp).astype(int)
grp=(grp%8999)+1000
print(grp)
'''
'''
grp=random.normal(size=(5,2), scale=99999)
grp=grp.astype(int)
grp=(grp%89999)+10000
print(grp)
'''
'''
grp=random.normal(size=(1,10), scale=9999)
grp=grp.astype(int)
grp=(grp%8999)+1000
print(grp)
''' '''
grp=random.normal(size=(5), scale=9999)
grp=abs(grp).astype(int)
grp=(grp%8999)+1000
#print(grp)
grp2=random.normal(size=(5), scale=99999)
grp2=abs(grp2).astype(int)
grp2=(grp2%89999)+10000
#print(grp2)

final=grp.tolist()+grp2.tolist()
print(final) '''

#ques:
'''
a=random.normal(size=(2,4), scale=10, loc=50)
a=abs(a).astype(int)
a=np.clip(a,10,99)
print(a)'''

#uniform method :method which can tell directly that how many values want to generate and give them directly.
'''
a=random.uniform(10,99,1000).astype(int)
print(a)'''

import numpy as np
from numpy import random
import seaborn as sb
import matplotlib.pyplot as plt
#bionominal distribution: it describes the outcome of binary scenario. 
#p=0.5, 5.7=6, 5.2=5
#n=number of trials : kitni baar run kara
#size: how many values you want to generate 
'''
a=random.binomial(n=1000,p=0.5,size=500)
print(a)
sb.displot(random.binomial(n=1000,p=0.5,size=500))
plt.show()'''
'''
a=random.binomial(n=1000,p=0.9,size=500)
newdata=np.sort(a)
print(newdata[::-1])'''       #desecending 
'''
a=random.binomial(n=1000,p=0.9,size=500)
newdata=np.sort(a)
print(newdata)            #asscending '''
'''
a=random.binomial(n=100,p=0.5,size=5)
print(a)
b=a.min()
print(b)
c=a.max()
print(c)
d=np.average(a)
print(d)
'''
'''
a=np.random.binomial(n=1000,p=0.5,size=20)
count=np.sum((a>=400)&(a<=500))
print(a)
print(count)'''
'''
a=np.random.binomial(n=30,p=0.7,size=30)
count=np.sum((a>=25))
print(a)
print(count)'''
'''
a=np.random.binomial(n=100,p=0.5,size=5)
b=sum(a)
print(a)
print(b)'''

#coin toss stimulation: n=1, p=0.5, size=20, count how many 1 and 0?
'''
a=np.random.binomial(n=1,p=0.5,size=20)
print(a)
print(sum(a))
tale=0
for i in a:
    if i==0:
        tale+=1
print(tale)'''

#write a program to print the data from 1-10 and count how many 5 are there?...........
'''
a=np.random.binomial(n=10,p=0.5,size=20)
print(a)
fives=np.sum((a==5))
print("fives:",fives)'''

#write a program of same stats and calculate into displot how many even and how many odd?
'''
a=np.random.binomial(n=10,p=0.5,size=20)
print(a)
even=0
odd=0
for i in a:
    if (i%2==0):
        even+=1
    else:
        odd+=1
labels=["even","odd"]
count=[even,odd]
sb.barplot(x=labels, y=count)
plt.show()'''

#find sum
'''
a=np.random.binomial(n=10,p=0.5,size=20)
b=np.sum(a)
print(a)
print("sum:",b)'''

#calculate how many is older than 25 from a excel data of 500s
import numpy as np
import random
import seaborn as sb
import matplotlib.pyplot as plt
import pandas as pd

'''
df=pd.read_excel('C:/Users/Yachi Vohra/OneDrive/Desktop/python,yachii/yachi.xlsx')
count=0
younger=0
for age in df['age']:
    if age>25:
        count+=1
    else:
        younger+=1
plt.bar(["elder","younger"],[count,younger])
plt.show()

df=pd.read_excel('C:/Users/Yachi Vohra/OneDrive/Desktop/python,yachii/yachi.xlsx')
count=0
younger=0
for age in df['age']:
    if age>50:
        count+=1
    else:
        younger+=1
plt.bar(["elder","younger"],[count,younger])
plt.show()
'''
'''
#poison distribution
a=np.random.poisson(size=50, lam=20)
print(a)

#uniform distribution: the bound distribution because in this you can bound the values 
# between the accurate range 

#low and high, low -sv, high-hv

a=np.random.uniform(1,5,10)
a=a.astype(int)
b=np.sum(a>3)
c=np.sum(a==1)
print(a)

#multinomial distribution: is the one nd most direct and easy distribution,
#  cuz this have its own count system depending on the probability

a=np.random.multinomial(n=6, pvals=[1/6,1/6,1/6])
print(a) 

#chi square distribution: works like a normal and binomial distribution but in this we have
#only two options (df & size) [it will take random number which are >0.]

a=np.random.chisquare(df=5,size=5).astype(int)
print(a)

import seaborn as sb
import matplotlib.pyplot as plt

a=np.random.chisquare(df=1,size=5000)
sb.displot(a, color='pink')
plt.show()

#rayleigh distribution
a=np.random.rayleigh(50,size=(50,50))
print(a)
sb.histplot(a,kde=True)
plt.show()

#pareto distribution
a=np.random.pareto(a=1,size=5)
sb.histplot(a,kde=True)
plt.show()'''


#FUNCTION 

'''
def check():
    print('hello yachi')
check()         #we call out the function in this

#OOPS 

class myclass:
    a=10
    name='yachi'
    float=67.8
b=myclass()
print(b.a)
print(b.name)
print(b.float)

# FUNCTION IN CLASS : if the function is in class then we have to
# call the function by object and also we have to mention self in the function.

class myclass:
    def yachi(self):
        print('my name is yachi')
a=myclass()
a.yachi()

#METHOD :always declare inside the class
class yachi:
    def __init__(self,a,b):
        print(a+b)
b=yachi(98,67)
print(b)

class yachi:
    def __init__(self,length,width):
        self.length=length
        self.width=width
        self.area=length*width
y=yachi(54,10)
print(y.area)

#other way 
class yachi:
    def __init__(self,length,width):
        self.length=length
        self.width=width
y=yachi(12,10)
print(y.length*y.width)'''

#UFUNCS : built in numpy function that performs operations element wise on arrays,
#making calculation fast and efficient.

#why we use UFUNCS? : because we have to use vectorization;
# where -boolen array or conditions, dtype -defining a return type area
#out -what will be the output

'''
x=[1,2,3,4]
y=[4,5,6,7]
z=[]
for i,j in zip(x,y):
    z.append(i+j)
print(z)

def add(x,y):
    return (x+y)    #if we use return in a function then we have to call it by using print
print(add(19,10))

def add(x,y):
    return (x+y)
add=np.frompyfunc(add,2,1)      
print(add([1,2,3,4],[5,6,7,8]))


#practice 
def add(x,y):
    return x+y
add=np.frompyfunc(add,2,1)
print(add([1,1,3,3],[5,6,7,8]))'''



'''
def add(a,b,c,d):
    return (a+b),(c+d)
add=np.frompyfunc(add,4,2)
print(add([1,1,1,1],[2,2,2,2],[3,3,3,3],[4,4,4,4]))


def add(a,b,c):
    return(a+b),(b+c)
add=np.frompyfunc(add,3,2)
print(add([1,1,1],[2,2,2],[3,3,3]))'''

'''
def calc(a,b,c,d):
    return a+b, c+d
fun=np.frompyfunc(calc,4,2)
x,y=fun([7,2],[5,3],[6,1],[9,3])
x=np.array(x,dtype=int)
y=np.array(y,dtype=int)
z=np.concatenate((x,y))
print(z)
print(np.sort(z))

def add(a,b,c):
    return (a+b),(b+c),(c+c),(a+c)
add=np.frompyfunc(add,3,4)
print(add([1,1],[2,2],[3,3]))'''

# def add(a,b,c,d):
#     return a+b, a*b,c+d, c*d
# fun=np.frompyfunc(add,4,4)
# x,y,u,v=fun([7,2],[5,3],[6,7],[9,8])
# x=np.array(x,dtype=int)
# y=np.array(y,dtype=int)
# u=np.array(u,dtype=int)
# v=np.array(v,dtype=int)
# z=np.concatenate((x,y,u,v))
# print(z)


# class yachi:
#     def __init__(self,a,b):
#         self.a=a
#         self.b=b
#         self.sum=a+b
# y=yachi(54,10)
# print(y.sum)

#def check(self,a,b,c,d):

# def myfunc(a,b,c,d):
#     if a%2==0:
#         return a+b+c+d
#     else:
#         return a*b*c*d
# myfunc=np.frompyfunc(myfunc,4,1)
# print(myfunc(
#     [1,2,3,4],
#     [0,9,8,7],
#     [2,2,9,9],
#     [10,20,30,40]
# ))

# #practice

# #1
# def crazy (a,b):
#     return a+b
# fun=np.frompyfunc(crazy,2,2)
# print(fun([10,20,30],[1,2,3])) 

#addition, subtraction, multiplication, division (simple arithmetic operations)
# import numpy as np
# a=np.array([11,11,12,13,14,15],dtype="int")
# b=np.array([20,21,22,23,24,25],dtype="int")

# newarr=np.add(a,b)
# print(newarr)

# newarr2=np.subtract(a,b)
# print(newarr2)

# newarr3=np.multiply(a,b)
# print(newarr3)

# newarr4=np.divide(a,b)
# print(newarr4)

# newarr5=np.power(a,b)       #works with dtype of object
# print(newarr5)

# newarr6=np.mod(a,b)
# print(newarr6)

# newarr7=np.remainder(a,b)       #mod and remainder is same
# print(newarr7)

# newarr8=np.divmod(a,b)           #works with dtype of int
# print(newarr8)
 
import numpy as np
np.set_printoptions(suppress=True) #this output is used to print the output in normal format

# a=np.array([1,2,3,4],dtype=int)
# b=np.array([11,12,13,14],dtype=int)
# c=np.array([5,1,2,3],dtype=int)
# d=np.array([2,2,2,2],dtype=int)

# newarr=np.zeros(4)
# for i in range(4):
#     if i==0:
#         newarr[i]=a[i]+b[i]+c[i]+d[i]
#     elif i==1:
#         newarr[i]=a[i]-b[i]-c[i]-d[i]
#     elif i==2:
#         newarr[i]=a[i]*b[1]*c[i]*d[i]
#     else:
#         newarr[i]=a[i]/b[i]/c[i]/d[i]
# print(newarr)
# for j in newarr:
#     print(j)


# a=np.array([1,2,3,4])
# b=np.array([5,6,7,8])
# asum=0
# for i in a:
#     asum+=i
# for j in b:
#     asum+=j
# print(asum)

# a=np.array([1,2,3,4])
# b=np.array([5,6,7,8])
# print(a*2)
# print(a/2)

# a=[10,40,70,100]
# for i in range(4):
#     print(sum(a[i:]))

#cummulative  (cumcum, cumprod)

#cumsum: will add and make the array
# a=np.array([[1,3,7,91],[2,0,9,5]])
# result=np.cumsum(a)
# print(result)

# a=np.array(['a','b','c'],dtype=object)
# result=np.cumsum(a)
# print(result)


#prod : direct multiply and convert into final answer
#cumprod: will multiply and make the array

# a=np.array([[1,2,3,4],[5,6,7,8]])
# result=np.cumprod(a)
# print(result)

#index (argmax, argmin)

# a=np.array([18,34,12,56,37])
# b=np.argmax(a)
# print(b)
# c=np.argmin(a)
# print(c)

# a=np.array([[12,2,14,15],[78,67,89,56]])
# b=np.argmax(a[0])
# c=np.argmax(a[1])
# print(b)
# print(c)

# a=np.array([[1,2,3,4],[3,3,4,9]])
# b=np.argmin(a,axis=1)        # axis=0 will compare the element wise of  both the dimensions
# print(b)

# a=np.array([42,34,46,40,32])
# for i in a:
#     if i>40:
#         print('true')
#     else:
#         print('false')

# a=np.array([42,34,46,40,32])
# result=np.any(a>40) #will give false if i use all
# print(result)

# a=np.array([42,45,34,36])
# result=np.argsort(a)    #sort p elements, argsort p indexing
# print(result)

# a=np.array([23,56,64,34,12])
# print(np.where(a>60))

#hw? last 4 ques tell value with index too

# #1
# a=np.array([23,56,64,34,12])
# for i in np.where(a>60)[0]:
#     print(i, a[i])

# #2
# a=np.array([42,45,34,36])
# b=np.argsort(a)
# c=np.sort(a)
# print(b,c)

# #3
# a=np.array([42,34,46,40,32])
# for i in np.where(a>40)[0]:
#     print(i,a[i])

# #4
# a=np.array([42,34,46,40,32])
# for i in a:
#     if i>40:
#         print(i,'true')
#     else:
#         print(i,'false')

#LCM
import numpy as np

# a=4
# b=80
# x=np.lcm(a,b)
# print(x)

# a=np.array([3,6,9,12])
# b=np.lcm.reduce(a)
# print(b)

#GCD- greatest common divisor
# a=6
# b=9
# x=np.gcd(a,b)
# print(x)

# a=np.array([3,6,9,12])
# x=np.gcd.reduce(a)
# print(x)

#TRIGNOMETRY

# a=np.array([np.pi/2,np.pi/5,np.pi/4])
# x=np.sin(a)
# print(x)

# a=np.array([np.pi/2,np.pi/5,np.pi/4])
# x=np.sin(a)
# print(x)

# a=np.array([np.pi/2,np.pi/5,np.pi/4])
# x=np.tan(a)
# print(x)

# a=np.array([np.pi/2,np.pi/5,np.pi/4])
# x=1/np.tan(a)
# print(x)

# a=np.array([np.pi/2,np.pi/5,np.pi/4])
# x=1/np.cos(a)
# print(x)

# a=np.array([np.pi/2,np.pi/5,np.pi/4])
# x=1/np.sin(a)
# print(x)

#hyperbolic
# a=np.sinh([np.pi/2])
# print(a)

# a=1/np.sinh([np.pi/2])
# print(a)
