import streamlit as st
import google.generativeai as genai
from datetime import datetime
from zoneinfo import ZoneInfo

genai.configure(api_key=st.secrets["GOOGLE_API_KEY"])

model = genai.GenerativeModel("models/gemini-2.5-flash")

st.title("🤖 Yora AI")
st.caption("Your Personal AI Assistant")

question = st.text_input("Ask me anything")

if st.button("Send"):

    india_time = datetime.now(ZoneInfo("Asia/Kolkata"))

    if "date" in question.lower():
        st.write("📅 Today's Date:", india_time.strftime("%d-%m-%Y"))

    elif "time" in question.lower():
        st.write("⏰ Current Time:", india_time.strftime("%H:%M:%S"))

    elif "date and time" in question.lower():
        st.write("📅 Date:", india_time.strftime("%d-%m-%Y"))
        st.write("⏰ Time:", india_time.strftime("%H:%M:%S"))

    else:
        response = model.generate_content(question)
        st.write(response.text)
        